✅ Long-term swing focus with daily/4-hour trend direction
✅ MACD crossovers for momentum confirmation
✅ Bollinger Bands for overbought/oversold entries
✅ Volume confirmation validates strength
✅ Strict risk control (50% max drawdown, 20 max trades)
✅ Trailing stops to capture extended moves
✅ Profit targets protect gains
✅ Lower frequency = Higher conviction trades
✅ Security locked with security_key
✅ Works on any symbol (optimized for liquid assets like GOLD, forex)

security_key = 2026